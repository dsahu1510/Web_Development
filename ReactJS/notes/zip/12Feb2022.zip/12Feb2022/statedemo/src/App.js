import React from 'react';
import axios from 'axios';
import Users from './Users';

class App extends React.Component{
    constructor(){
      console.log("App Component loading - in progress");
       super();
       this.state= {
           users: []
       }
    }
    componentDidMount(){
         console.log("component did mount is called");
         axios.get("https://jsonplaceholder.typicode.com/users").then(
           response => {
             console.log(response.data);
              this.setState({
                users:response.data
              })
           }
         )
    }
    render(){
      console.log("render method called");
        return(
          <div>
            <h1>App Component!</h1>
                <Users users={this.state.users}/>
          </div>
        )
    }
}
export default App;
