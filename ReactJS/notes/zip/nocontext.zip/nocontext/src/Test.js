import React from 'react';

class Test extends React.Component{

     render(){

        if(10 == 10){
             throw new Error('Intentional Error'); 
        }

        return(
            <div>
                   <h1>This is a test component</h1>
            </div>
        )
     }

}

export default Test;