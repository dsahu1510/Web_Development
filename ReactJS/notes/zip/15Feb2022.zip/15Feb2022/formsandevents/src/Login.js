import React from 'react';

class Login extends React.Component{

    constructor(){
        super();
        this.state= {
            username: "",
            password: ""
        }
        
    }

    updateState = (event)=>{
        console.log("updateState");
        var value = event.target.value;
        var name = event.target.name;
        this.setState({[name]:value});
    }
    handleSubmit = (event) => {
        event.preventDefault();
          console.log(this.state);
    }

    render(){
        return(
            <div>
                <h1>Login Here</h1>
                <form onSubmit={this.handleSubmit}>
                <input type="text" name="username" onChange ={this.updateState} placeholder="username here" ></input> <br></br><br></br>
                <input type="text" name="password"  onChange={this.updateState} placeholder="password here" ></input><br></br><br></br>
                <button>Login</button>
                </form>
            </div>
        )
    }
  
}
export default Login;

/*

c360 
Kaveri envrionments 

*/