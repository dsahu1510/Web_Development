import logo from './logo.svg';
import './App.css';
import User from './User';
import Product from './Product';

function App() {
  return (
    <div className="App">
         <Product></Product>
         <User></User>
    </div>
  );
}

export default App;
