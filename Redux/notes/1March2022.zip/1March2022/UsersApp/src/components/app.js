import React, { Component } from 'react';
import User from '../containers/User';

export default class App extends Component {
  render() {
    return (
      <div>
        <User/>
      </div>
    );
  }
}
