import React from 'react';
import Counter from './Counter';
import ErrorBoundary from './ErrorBoundary';

class App extends React.Component{

  render(){
   return(
     <div>
       <h1>App</h1>
       <ErrorBoundary>
       <Counter/>
       </ErrorBoundary>
       
     </div>
   )
  }

}
export default App;