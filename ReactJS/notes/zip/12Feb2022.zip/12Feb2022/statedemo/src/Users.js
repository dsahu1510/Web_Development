import React from 'react';

class Users extends React.Component{

    render(){
        return(
            <div>
                Users count, {this.props.users.length}
            </div>
        )
    }

}
export default Users;