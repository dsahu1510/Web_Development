import React from 'react';

class Login extends React.Component{

    constructor(){
        super();
        this.state= {
            username: ""
        }
        console.log("Constructor called - Login!!");
    }
    componentDidMount(){
        console.log("Component did mount called - Login");
    }
    componentDidUpdate(){
        console.log("Component Did update called - Login");
    }
    updateState = (event) => {
        var value = event.target.value;
        this.setState({username:value});
    }
    render(){
        console.log("render method called - Login")
        return(
            <div>
                <h1>This is Login Component!!</h1>
                <input type="text" onChange={this.updateState}></input>
            </div>
        )
    }
    componentWillUnmount(){
        console.log("component will unmount is called -Login");
    }

}

export default Login;