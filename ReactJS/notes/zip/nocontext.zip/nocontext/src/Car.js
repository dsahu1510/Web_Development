import React, { Component } from 'react';
const Car = props => (
    <React.Fragment>
        <p>Name: {props.name}</p>
        <p>Price: ${props.price}</p>
        <button onClick={props.incrementPrice}>&uarr;</button>
        <button onClick={props.decrementPrice}>&darr;</button>
    </React.Fragment>
);

export default Car;

/*

App    [cars objects, inc and dec]

|

Product List   [cars objects, inc and dec]

|

Cars   [cars objects, inc and dec]

|

Car   (car object,inc and dec)


*/