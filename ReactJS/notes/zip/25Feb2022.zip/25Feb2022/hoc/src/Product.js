import React from 'react';
import Hoc from './Hoc';

class Product extends React.Component{
     
       render(){
           return(
               <div> 
                  Products Count, <h1 onClick={this.props.updateCounter}>{this.props.counter}</h1>
               </div>
           )
       }
}

 const ProductHOC=Hoc(Product,900);
export default ProductHOC;