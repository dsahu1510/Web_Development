import React from 'react';

class Register extends React.Component{
    render(){
        return(
            <div>
                <h1>This is Register Component!!</h1>
            </div>
        )
    }
}
export default Register;