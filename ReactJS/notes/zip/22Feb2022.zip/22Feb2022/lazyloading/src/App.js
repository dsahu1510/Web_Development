import React,{ Suspense } from 'react';

const LoginComponent = React.lazy(() => import('./Login'))

class App extends React.Component{

     render(){
       return(
         <div>
           <h1>App Component</h1>
           <Suspense fallback={<h1>Loading......</h1>}>
              <LoginComponent></LoginComponent>
           </Suspense>
         </div>
       )
     }

}

export default App;
