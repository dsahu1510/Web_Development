function Login(){
    return (
        <div>
               <form>
                   Username:<input type="text"></input>
                   Password: <input type="password"></input>
                   <button>Login</button>
               </form>
        </div>
    )
}
export default Login;