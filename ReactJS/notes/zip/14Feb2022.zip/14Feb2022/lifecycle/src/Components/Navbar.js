import React from 'react';
import {NavLink, HashRouter,Route} from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import Contact from './Contact';

class Navbar extends React.Component{
    render(){
        return(
            <div>
                 <HashRouter>
                 <NavLink  to="/login">Login</NavLink> &nbsp;&nbsp;&nbsp;&nbsp;
                 <NavLink  to="/register">Register</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;
                 <NavLink  to="/contact">Contact</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;
                 {/* <Route exact path="/" component={Login}></Route> */}
                  <Route path="/login" component={Login}></Route>
                  <Route path="/register" component={Register}></Route>
                  <Route path="/contact" component={Contact}></Route>
                 </HashRouter>
            </div>
        )
    }
}
export default Navbar;