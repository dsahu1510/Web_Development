import React from 'react';
import User from './User';

class App extends React.Component{

    username ="Sai Kumar";

 render(){
     return (<div>
            
             <User uname={this.username} />

     </div>)
 }    

}
export default App;