import React from 'react';
import logo from './logo.svg';
import './App.css';
import ProductList from './ProductList';
import Test from './Test';
import ErrorBoundary from './ErrorBoundary';

class App extends React.Component {

 

    render(){

         return(
             <div>
                 <h1>This is Some Data</h1>
                 <ErrorBoundary>
                 <Test/>
                 </ErrorBoundary>
                 
             </div>
         )
    }



//   state = {
//       cars: {
//           car001: { name: 'Honda', price: 100 },
//           car002: { name: 'BMW', price: 150 },
//           car003: { name: 'Mercedes', price: 200 }
//       }
//   };
//   incrementCarPrice = this.incrementCarPrice.bind(this);
//   decrementCarPrice = this.decrementCarPrice.bind(this);

//   incrementCarPrice(selectedID) {
//       // a simple method that manipulates the state
//       const cars = Object.assign({}, this.state.cars);
//       cars[selectedID].price = cars[selectedID].price + 1;
//       this.setState({
//           cars
//       });
//   }

//   decrementCarPrice(selectedID) {
//       // a simple method that manipulates the state
//       const cars = Object.assign({}, this.state.cars);
//       cars[selectedID].price = cars[selectedID].price - 1;
//       this.setState({
//           cars
//       });
//   }

//   render() {
//       return (
//           <div className="App">
             
//               {/* Pass props twice */}
              
//             <ProductList
//                   cars={this.state.cars}
//                   incrementCarPrice={this.incrementCarPrice}
//                   decrementCarPrice={this.decrementCarPrice}
//               /> 
             
//           </div>
//       );
//   }
}

export default App;
