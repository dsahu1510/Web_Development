
import React from 'react';
import YTSearch from 'youtube-api-search';
import VideoList from './components/VideoList';
import VideoPlayer from './components/VideoPlayer';

const API_KEY = "AIzaSyDkjxpRVglEe4HVzp86NM17Q1ECXp8EZes";

class App extends React.Component{
   constructor(){
     super();
     this.state = {
       videos: [],
       selectedVideo : null
     }
   }
   componentDidMount(){
     YTSearch({key:API_KEY,term:'digitallync'},(videos) => {
         console.log(videos);
         this.setState({videos:videos, selectedVideo:videos[0]});
     })
   }
   render(){
     return(
       <div>
         
         <VideoPlayer video = {this.state.selectedVideo}/>
          <VideoList videoSelection={ video => {this.setState({ selectedVideo:video })}} videos = {this.state.videos}></VideoList>
       </div>
     )
   }
}
export default App;
