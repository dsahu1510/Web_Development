import React from 'react';

class App extends React.Component{

     constructor(){
       super();
       this.state= {
         
         products: [
           {
             pid:102,
             name:"product 1",
             price:3000,
             brand:"Brand A"
           },
           {
            pid:103,
            name:"product 2",
            price:13000,
            brand:"Brand B"
          },
          {
            pid:104,
            name:"product 3",
            price:30900,
            brand:"Brand C"
          },
          {
            pid:105,
            name:"product 4",
            price:2000,
            brand:"Brand A"
          }
         ]
       }
     }
      rList = () => {
       var listItems= this.state.products.map((product) => {
             return <li key={product.pid}>{product.pid} {product.name}{product.price}{product.brand}</li>
        })
        console.log("listItems", listItems);
        return listItems;
      }

      render(){
          return(
            <div>
                  <ul>
                         {this.rList()}
                  </ul>
            </div>
          )
      }
}

export default App;
