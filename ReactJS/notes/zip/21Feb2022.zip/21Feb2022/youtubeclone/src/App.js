
import React from 'react';
import YTSearch from 'youtube-api-search';
import Navbar from './components/Navbar';

const API_KEY = "AIzaSyDkjxpRVglEe4HVzp86NM17Q1ECXp8EZes";

class App extends React.Component{
   

   render(){
     return(
       <div>
        
           <Navbar></Navbar>
       </div>
     )
   }
}
export default App;
