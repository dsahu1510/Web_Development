import React from 'react';
import Hoc from './Hoc';

class User extends React.Component{
       render(){
           return(
               <div> 
                  Users Count, <h1 onClick={this.props.updateCounter}>{this.props.counter}</h1>
               </div>
           )
       }
}
const UserHOC=Hoc(User,10);
export default UserHOC;