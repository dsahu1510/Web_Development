import React from 'react';

class App extends React.Component{

  constructor(){
    super();
     this.state = {
        isUserLoggedIn : false
     }
  }

  render(){
    
       if(this.state.isUserLoggedIn){
        return(
          <div>
                <h1>User Logged In!!</h1>  
                <button onClick={() =>{
                       this.setState({isUserLoggedIn:false});
                }}>Logout</button>
          </div>
        )
       }
       else
       {
        return(
          <div>
                <h1>User Logged Out!!</h1>  
                <button onClick={() =>{
                       this.setState({isUserLoggedIn:true});
                }}>Login</button>
          </div>
        )
       }

   
  }
}

export default App;
