var name = "password";

var obj = {
    [name]: "ravi"
}

console.log(obj);