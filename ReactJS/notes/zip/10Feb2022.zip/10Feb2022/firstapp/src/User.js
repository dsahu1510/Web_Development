import React from 'react';

class User extends React.Component{

    render(){
         console.log(this.props);
         return(
             <div>
                 <h1>User, {this.props.uname}</h1>
             </div>
         )

    }

}
export default User;